### Parkour - By: Driesboy, and SirGamer.
# TestServer:
gamecraftpe.tk 
port 19132

[![Join the chat at https://gitter.im/Driesboy/Parkour](https://badges.gitter.im/Driesboy/Parkour.svg)](https://gitter.im/Driesboy/Parkour?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

### How it works:

1: Create a sign with the text [Checkpoint] or Block (see config to change block id) and [Earn Reward]

2: If the player falls from the parkour, they fall into the void.

3: Tap the sign!

4: Jump into the void...

5: The plugin will teleport you to your last checkpoint! BOOM.

### Tap the picture below to watch how our plugin works.

[![Alt text for your video](http://img.youtube.com/vi/L8BLJxsi6tI/0.jpg)](http://www.youtube.com/watch?v=L8BLJxsi6tI)

###Description - Allows players to set checkpoints, and earn rewards for doing a Parkour course.
