<?php

namespace AG;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\utils\TextFormat;
use pocketmine\Player;
use pocketmine\level\Position;
use pocketmine\level\Level;
use pocketmine\entity\Entity;
use pocketmine\math\Vector3;
use pocketmine\event\player\PlayerMoveEvent;

class Main extends PluginBase implements Listener{
	
	private $config;
	private $pos;
	public function onEnable(){
		$this->getServer()->getLogger()->info(TextFormat::BLUE . "===================");
		$this->getServer()->getLogger()->info(TextFormat::BLUE . "Plugin VoidLoop");
		$this->getServer()->getLogger()->info(TextFormat::BLUE . "By : AnnonymousGames");
		$this->getServer()->getLogger()->info(TextFormat::BLUE . "===================");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		@mkdir($this->getDataFolder());
		    $this->saveDefaultConfig();
	    $this->data = new Config($this->getDataFolder()."Data.yml", Config::YAML, array());
	}
	
     public function onVoidLoop(PlayerMoveEvent $event){
          if($event->getTo()->getFloorY() < 1){
             	$player = $event->getPlayer();
             	$name = $event->getPlayer()->getName();             	
             	$name = strtolower($name);
             	$pos = $this->data->get($name);
				if(is_array($pos)){
					$player->sendMessage("{$this->getConfig()->get("VoidLoop")}");
						$level = $this->getServer()->getLevelByName($pos[3]);
						$player->teleport(new Position($pos[0],$pos[1],$pos[2],$level));
					}else{ 
					$player->teleport($player->getLevel()->getSafeSpawn());
			}
                }
        }
}
